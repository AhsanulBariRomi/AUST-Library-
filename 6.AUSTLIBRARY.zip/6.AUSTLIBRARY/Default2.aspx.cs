﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=MSI\sqlexpress;Initial Catalog=Library;Integrated Security=True");
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    string qr;
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {

            qr = "Insert into Student(id, name, password, semester, department, mail, [phn no]) values('" + TextBox2.Text.Trim() + "','" + TextBox1.Text.Trim() + "','" + TextBox3.Text.Trim() + "','" + TextBox4.Text.Trim() + "','" + TextBox5.Text.Trim() + "','" + TextBox6.Text.Trim() + "','" + TextBox7.Text.Trim()+"')";
            cmd = new SqlCommand(qr, con);
            con.Open();   //sqlconnection open before save or delete update or serach
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                lblresult.ForeColor = System.Drawing.Color.Green;

                Response.Write("Successfully Registered");

            }
            else
            {
                Response.Write("The usernames taken");
            }
            con.Close();

        }
        catch(Exception ex)
        {
            con.Close();
            Response.Write("Error:Same user id can't be used"); //+ex.ToString()
        }
        //Response.Redirect("Default4.aspx");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {
        
    }
}